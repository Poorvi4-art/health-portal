from django.shortcuts import render
from .models import Patient
from sklearn.cluster import KMeans
import numpy as np

def home(request):
    patients = Patient.objects.all()
    if patients:
        data = np.array([[p.age, p.blood_pressure, p.cholesterol, p.glucose] for p in patients])
        kmeans = KMeans(n_clusters=2, random_state=0).fit(data)
        results = list(zip(patients, kmeans.labels_))
    else:
        results = []

    return render(request, 'home.html', {'results': results})
