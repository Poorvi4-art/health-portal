from django.db import models

class Patient(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    blood_pressure = models.FloatField()
    cholesterol = models.FloatField()
    glucose = models.FloatField()

    def __str__(self):
        return self.name
